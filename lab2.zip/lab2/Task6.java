import java.util.Scanner;
public class Task6{
    public static void main(String[]args){
        int age;
        System.out.println("Enter the age : ");
        Scanner inp=new Scanner(System.in);
        age=inp.nextInt();
    if(age>=18){
        System.out.println("the user is eligilble for voting ");
    }else{
        System.out.println("not eligible");
    }
inp.close();
    }
}