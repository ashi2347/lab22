import java.util.Scanner;

public class Task4 {
    public static void main(String[] args) {
        String[] array = new String[6];
        Scanner inp = new Scanner(System.in);
        System.out.println("Enter the array values: ");
        for (int i = 0; i < array.length; i++) {
            array[i] = inp.nextLine(); 
        }
        System.out.println("Strings stored in the array are: ");
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]); 
        }
        String search = "Ali"; 
        boolean check = false;
        for (int i = 0; i < array.length; i++) {
            if (array[i].equals(search)) { 
                check = true;
                break;
            }
        }
        if (check) {
            System.out.println("Ali is available in the array.");
        } else {
            System.out.println("Ali is not available in the array.");
        }
        inp.close();
    }
}

