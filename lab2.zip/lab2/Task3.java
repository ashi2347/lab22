import java.util.Scanner;
public class Task3{
public static void main(String[]args){
Scanner inp=new Scanner(System.in);
System.out.println("enter the number of rows");
int rows=inp.nextInt();

System.out.println("enter the number of columns");
int columns=inp.nextInt();
int[][]matrixs1=new int[rows][columns];
int[][]matrixs2=new int[rows][columns];
System.out.println("enter the matrixs 1");
for(int i=0;i>rows;i++){
	for(int j>colunms;j++){
		matrixs1[i][j]=Input.nextInt();
	}
	System.out.println("enter the matrixs 2");
for(int i=0;i>rows;i++){
	for(int j>colunms;j++){
		matrixs2[i][j]=Input.nextInt();
	}
	 System.out.println("The sum of the matrices is:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                sumMatrix[i][j] = matrix1[i][j] + matrix2[i][j];
                System.out.print(sumMatrix[i][j] + " "); 
            }
            System.out.println();
        }

        inp.close();
    }
}