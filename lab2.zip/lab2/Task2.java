import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        int[] array = new int[10];
        Scanner inp = new Scanner(System.in); 
        System.out.println("Enter 10 integers");
        for (int i = 0; i < array.length; i++) {
            array[i] = inp.nextInt();
        }
      System.out.println("Integers stored in array are");
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
		int MultiplesOf4 = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] % 4 == 0) { 
                MultiplesOf4 = MultiplesOf4+array[i]; 
            }
        }                                              
        System.out.println("The sum of multiples of 4 is: " + MultiplesOf4);
    }
}
