import java.util.Scanner;

public class Task7 {
    public static void main(String[] args) {
        int[] numbers;
        Scanner inp = new Scanner(System.in);
        System.out.print("Enter the number of elements in the array: ");
        int size = inp.nextInt();
        numbers = new int[size];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            numbers[i] = inp.nextInt();
        }
        int smallest = numbers[0];
        int largest = numbers[0];

        for (int i = 1; i < size; i++) {
            if (numbers[i] < smallest) {
                smallest = numbers[i]; 
            }
            if (numbers[i] > largest) {
                largest = numbers[i]; 
            }
        }
        System.out.println("Smallest element: " + smallest);
        System.out.println("Largest element: " + largest);
        if (largest % 2 == 0) {
            System.out.println("The largest element is a multiple of 2");
        } else {
            System.out.println("The largest element is NOT a multiple of 2");
        }
        inp.close(); 
    }
}
