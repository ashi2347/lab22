import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        char[] const_arr = {'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z'};
        Scanner input = new Scanner(System.in);  
        System.out.println("Enter a character");
        char user_inp = input.next().charAt(0);  
        boolean check = false;
        for (int i = 0; i < const_arr.length; i++) {
            if (user_inp == const_arr[i]) {
                check = true;
                break;
            }
        }
        if (check) {
            System.out.println("consonant available");
        } else {
            System.out.println("not available");
        }
    }
}

