import java.util.Scanner;
public class Task5{
    public staticvoid main(String[]args){
        int[]array={1,1,0,0,1},
                   {1,0,1,0,1},
                   {1,0,0,1,1},
                   {1,0,0,0,1}, 
    };
     if (letterN(matrix)) {
            System.out.println("The matrix contains the letter 'N'.");
        } else {
            System.out.println("The matrix does not contain the letter 'N'.");
        }
    }

}